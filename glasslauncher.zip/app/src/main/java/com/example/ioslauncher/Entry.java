package com.example.ioslauncher;

import android.content.Intent;
import android.graphics.Bitmap;

/** Элемент лаунчера: приложение или служебная иконка (поиск, настройки, пункт управления). */
final class Entry {
    static final int U_NONE = 0;
    static final int U_SEARCH = 1;
    static final int U_SETTINGS = 2;
    static final int U_CONTROL = 3;

    String label = "";
    String shown = "";   // подпись, обрезанная под текущую ширину
    String pkg = "";
    Intent intent;
    Bitmap icon;         // готовая иконка в стиле iOS
    boolean system;
    int util = U_NONE;
}
