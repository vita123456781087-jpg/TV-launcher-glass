package com.example.ioslauncher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;

import java.util.Random;

/**
 * Всё, что готовится один раз заранее: ночной фон, размытая копия фона для стекла,
 * иконки в форме iOS, тень и векторные значки. Во время работы на экран выводятся
 * только готовые картинки, поэтому лаунчер «летает» на слабой приставке.
 */
final class Art {

    static final int G_SEARCH = 1;
    static final int G_SLIDERS = 2;
    static final int G_WIFI = 3;
    static final int G_VOLUME = 4;
    static final int G_RAM = 5;
    static final int G_FOLDER = 6;
    static final int G_MOON = 7;
    static final int G_COG = 8;
    static final int G_CONTROL = 9;

    private Art() { }

    // ------------------------------------------------------------ ночной фон

    static Bitmap night(int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setDither(true);
        p.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{0xFF040612, 0xFF0A0F2E, 0xFF1B1247},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        glow(c, p, w * 0.15f, h * 0.85f, h * 0.75f, 0x4B2BA8, 0x66);
        glow(c, p, w * 0.88f, h * 0.20f, h * 0.60f, 0x1FA5B8, 0x40);
        glow(c, p, w * 0.60f, h * 1.05f, h * 0.60f, 0xB03A9A, 0x50);

        p.setShader(null);
        Random r = new Random(27);
        for (int i = 0; i < 140; i++) {
            float x = r.nextFloat() * w;
            float y = r.nextFloat() * h * 0.75f;
            float rad = (0.4f + r.nextFloat() * 0.9f) * (h / 360f);
            int a = 70 + r.nextInt(160);
            p.setColor((a << 24) | 0x00FFFFFF);
            c.drawCircle(x, y, rad, p);
        }
        return b;
    }

    private static void glow(Canvas c, Paint p, float x, float y, float r, int rgb, int alpha) {
        p.setShader(new RadialGradient(x, y, r,
                new int[]{(alpha << 24) | (rgb & 0x00FFFFFF), rgb & 0x00FFFFFF},
                null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
    }

    // ---------------------------------------------------------------- размытие

    /** Уменьшенная размытая копия картинки: из неё рисуется «матовое стекло». */
    static Bitmap blurred(Bitmap src, int w, int h, int radius) {
        Bitmap s = Bitmap.createScaledBitmap(src, w, h, true);
        int[] px = new int[w * h];
        s.getPixels(px, 0, w, 0, 0, w, h);
        blur(px, w, h, radius);
        blur(px, w, h, radius);
        if (s != src) s.recycle();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    private static int clampi(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static void blurRows(int[] src, int[] dst, int w, int h, int r) {
        int win = 2 * r + 1;
        for (int y = 0; y < h; y++) {
            int o = y * w;
            int sa = 0, sr = 0, sg = 0, sb = 0;
            for (int i = -r; i <= r; i++) {
                int p = src[o + clampi(i, 0, w - 1)];
                sa += p >>> 24;
                sr += (p >> 16) & 255;
                sg += (p >> 8) & 255;
                sb += p & 255;
            }
            for (int x = 0; x < w; x++) {
                dst[o + x] = ((sa / win) << 24) | ((sr / win) << 16) | ((sg / win) << 8) | (sb / win);
                int po = src[o + clampi(x - r, 0, w - 1)];
                int pi = src[o + clampi(x + r + 1, 0, w - 1)];
                sa += (pi >>> 24) - (po >>> 24);
                sr += ((pi >> 16) & 255) - ((po >> 16) & 255);
                sg += ((pi >> 8) & 255) - ((po >> 8) & 255);
                sb += (pi & 255) - (po & 255);
            }
        }
    }

    private static void transpose(int[] src, int[] dst, int w, int h) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) dst[x * h + y] = src[y * w + x];
        }
    }

    // Размытие по строкам, затем по столбцам (через транспонирование)
    private static void blur(int[] a, int w, int h, int r) {
        int[] b = new int[a.length];
        blurRows(a, b, w, h, r);
        transpose(b, a, w, h);
        blurRows(a, b, h, w, r);
        transpose(b, a, h, w);
    }

    // ------------------------------------------------------------ форма iOS

    /** Плавный «суперэллипс» как у иконок iOS. */
    static Path squircle(float x, float y, float s) {
        Path p = new Path();
        int n = 72;
        double e = 2.0 / 5.0;
        float a = s / 2f;
        float cx = x + a;
        float cy = y + a;
        for (int i = 0; i <= n; i++) {
            double t = 2 * Math.PI * i / n;
            double ct = Math.cos(t);
            double st = Math.sin(t);
            float px = cx + (float) (a * Math.signum(ct) * Math.pow(Math.abs(ct), e));
            float py = cy + (float) (a * Math.signum(st) * Math.pow(Math.abs(st), e));
            if (i == 0) p.moveTo(px, py);
            else p.lineTo(px, py);
        }
        p.close();
        return p;
    }

    static Bitmap mask(int s) {
        Bitmap m = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        new Canvas(m).drawPath(squircle(0, 0, s), p);
        return m;
    }

    /** Мягкая тень под иконкой. */
    static Bitmap shadow(int s) {
        int bs = Math.round(s * 1.5f);
        Bitmap b = Bitmap.createBitmap(bs, bs, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xB0000000);
        float off = (bs - s) / 2f;
        new Canvas(b).drawPath(squircle(off, off, s), p);
        int[] px = new int[bs * bs];
        b.getPixels(px, 0, bs, 0, 0, bs, bs);
        int r = Math.max(2, bs / 14);
        blur(px, bs, bs, r);
        blur(px, bs, bs, r);
        b.setPixels(px, 0, bs, 0, 0, bs, bs);
        return b;
    }

    private static boolean opaque(Bitmap b, int x, int y) {
        return Color.alpha(b.getPixel(x, y)) >= 245;
    }

    private static int mixc(int a, int b, float t) {
        return Color.rgb(Math.round(Color.red(a) * t + Color.red(b) * (1 - t)),
                Math.round(Color.green(a) * t + Color.green(b) * (1 - t)),
                Math.round(Color.blue(a) * t + Color.blue(b) * (1 - t)));
    }

    private static int dominant(Bitmap b) {
        Bitmap t = Bitmap.createScaledBitmap(b, 8, 8, true);
        long r = 0, g = 0, bl = 0, n = 0;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                int p = t.getPixel(x, y);
                if (Color.alpha(p) < 128) continue;
                r += Color.red(p);
                g += Color.green(p);
                bl += Color.blue(p);
                n++;
            }
        }
        if (t != b) t.recycle();
        if (n == 0) return 0xFF5B6478;
        return Color.rgb((int) (r / n), (int) (g / n), (int) (bl / n));
    }

    /** Иконка приложения в форме iOS: плитка с градиентом, блик и тонкая рамка. */
    static Bitmap iosIcon(Drawable d, int s, Bitmap mask) {
        Bitmap src = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas sc = new Canvas(src);
        boolean drawn = false;
        if (Build.VERSION.SDK_INT >= 26 && d instanceof AdaptiveIconDrawable) {
            // слои без системной маски: фон на весь квадрат, передний план по центру
            AdaptiveIconDrawable ad = (AdaptiveIconDrawable) d;
            int big = Math.round(s * 1.5f);
            int off = -(big - s) / 2;
            Drawable bgd = ad.getBackground();
            Drawable fgd = ad.getForeground();
            if (bgd != null) {
                bgd.setBounds(off, off, off + big, off + big);
                bgd.draw(sc);
            }
            if (fgd != null) {
                fgd.setBounds(off, off, off + big, off + big);
                fgd.draw(sc);
            }
            drawn = bgd != null || fgd != null;
        }
        if (!drawn) {
            d.setBounds(0, 0, s, s);
            d.draw(sc);
        }

        boolean full = opaque(src, 1, 1) && opaque(src, s - 2, 1)
                && opaque(src, 1, s - 2) && opaque(src, s - 2, s - 2);

        Bitmap out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setFilterBitmap(true);

        if (full) {
            c.drawBitmap(src, 0, 0, p);
        } else {
            int dom = dominant(src);
            double lum = (0.299 * Color.red(dom) + 0.587 * Color.green(dom)
                    + 0.114 * Color.blue(dom)) / 255.0;
            if (lum > 0.78) dom = 0xFF3A4254;      // белый значок: тёмная плитка
            else if (lum < 0.12) dom = 0xFF4A5368; // чёрный значок: светлая плитка
            int top = mixc(dom, 0xFFFFFFFF, 0.78f);
            int bottom = mixc(dom, 0xFF000000, 0.72f);
            p.setShader(new LinearGradient(0, 0, 0, s, top, bottom, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, s, s, p);
            p.setShader(null);
            float in = s * 0.17f;
            c.drawBitmap(src, null, new RectF(in, in, s - in, s - in), p);
        }
        finishIcon(c, s, mask);
        src.recycle();
        return out;
    }

    /** Служебная иконка: цветная плитка с белым значком. */
    static Bitmap glyphIcon(int glyph, int s, int c1, int c2, Bitmap mask) {
        Bitmap out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, s, c1, c2, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, s, s, p);
        Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
        glyph(c, g, glyph, s / 2f, s / 2f, s * 0.52f, 0xFFFFFFFF, s * 0.055f);
        finishIcon(c, s, mask);
        return out;
    }

    // Блик сверху, обрезка по форме и светлая рамка
    private static void finishIcon(Canvas c, int s, Bitmap mask) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, s * 0.55f, 0x55FFFFFF, 0x00FFFFFF,
                Shader.TileMode.CLAMP));
        c.drawRect(0, 0, s, s * 0.55f, p);

        Paint m = new Paint();
        m.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawBitmap(mask, 0, 0, m);

        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeWidth(Math.max(1.5f, s * 0.012f));
        bp.setColor(0x66FFFFFF);
        c.drawPath(squircle(s * 0.006f, s * 0.006f, s * 0.988f), bp);
    }

    // ---------------------------------------------------------------- значки

    /** Рисует значок внутри квадрата со стороной s с центром (cx, cy). */
    static void glyph(Canvas c, Paint p, int id, float cx, float cy, float s, int color,
                      float sw) {
        p.setColor(color);
        p.setStrokeWidth(sw);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        RectF r = new RectF();
        Path path = new Path();
        switch (id) {
            case G_SEARCH:
                p.setStyle(Paint.Style.STROKE);
                c.drawCircle(cx - s * 0.08f, cy - s * 0.08f, s * 0.26f, p);
                c.drawLine(cx + s * 0.11f, cy + s * 0.11f, cx + s * 0.34f, cy + s * 0.34f, p);
                break;
            case G_SLIDERS: {
                float[] ys = {cy - s * 0.26f, cy, cy + s * 0.26f};
                float[] kx = {cx - s * 0.15f, cx + s * 0.18f, cx - s * 0.05f};
                for (int i = 0; i < 3; i++) {
                    p.setStyle(Paint.Style.STROKE);
                    c.drawLine(cx - s * 0.38f, ys[i], cx + s * 0.38f, ys[i], p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(kx[i], ys[i], s * 0.09f, p);
                }
                break;
            }
            case G_WIFI: {
                p.setStyle(Paint.Style.STROKE);
                float oy = cy + s * 0.22f;
                float[] rad = {s * 0.18f, s * 0.34f, s * 0.50f};
                for (float rr : rad) {
                    r.set(cx - rr, oy - rr, cx + rr, oy + rr);
                    c.drawArc(r, -135f, 90f, false, p);
                }
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, oy, s * 0.05f, p);
                break;
            }
            case G_VOLUME:
                p.setStyle(Paint.Style.FILL);
                path.moveTo(cx - s * 0.36f, cy - s * 0.12f);
                path.lineTo(cx - s * 0.18f, cy - s * 0.12f);
                path.lineTo(cx + s * 0.04f, cy - s * 0.30f);
                path.lineTo(cx + s * 0.04f, cy + s * 0.30f);
                path.lineTo(cx - s * 0.18f, cy + s * 0.12f);
                path.lineTo(cx - s * 0.36f, cy + s * 0.12f);
                path.close();
                c.drawPath(path, p);
                p.setStyle(Paint.Style.STROKE);
                r.set(cx + s * 0.04f - s * 0.16f, cy - s * 0.16f, cx + s * 0.04f + s * 0.16f, cy + s * 0.16f);
                c.drawArc(r, -50f, 100f, false, p);
                r.set(cx + s * 0.04f - s * 0.30f, cy - s * 0.30f, cx + s * 0.04f + s * 0.30f, cy + s * 0.30f);
                c.drawArc(r, -50f, 100f, false, p);
                break;
            case G_RAM: {
                p.setStyle(Paint.Style.STROKE);
                r.set(cx - s * 0.26f, cy - s * 0.26f, cx + s * 0.26f, cy + s * 0.26f);
                c.drawRoundRect(r, s * 0.06f, s * 0.06f, p);
                float[] pin = {-0.12f, 0f, 0.12f};
                for (float k : pin) {
                    c.drawLine(cx + s * k, cy - s * 0.26f, cx + s * k, cy - s * 0.38f, p);
                    c.drawLine(cx + s * k, cy + s * 0.26f, cx + s * k, cy + s * 0.38f, p);
                    c.drawLine(cx - s * 0.26f, cy + s * k, cx - s * 0.38f, cy + s * k, p);
                    c.drawLine(cx + s * 0.26f, cy + s * k, cx + s * 0.38f, cy + s * k, p);
                }
                break;
            }
            case G_FOLDER:
                p.setStyle(Paint.Style.STROKE);
                r.set(cx - s * 0.38f, cy - s * 0.18f, cx + s * 0.38f, cy + s * 0.30f);
                c.drawRoundRect(r, s * 0.06f, s * 0.06f, p);
                path.moveTo(cx - s * 0.38f, cy - s * 0.18f);
                path.lineTo(cx - s * 0.38f, cy - s * 0.30f);
                path.lineTo(cx - s * 0.10f, cy - s * 0.30f);
                path.lineTo(cx, cy - s * 0.18f);
                c.drawPath(path, p);
                break;
            case G_MOON: {
                p.setStyle(Paint.Style.FILL);
                Path outer = new Path();
                outer.addCircle(cx, cy, s * 0.30f, Path.Direction.CW);
                Path cut = new Path();
                cut.addCircle(cx + s * 0.16f, cy - s * 0.10f, s * 0.26f, Path.Direction.CW);
                outer.op(cut, Path.Op.DIFFERENCE);
                c.drawPath(outer, p);
                break;
            }
            case G_COG:
                p.setStyle(Paint.Style.STROKE);
                c.drawCircle(cx, cy, s * 0.17f, p);
                for (int i = 0; i < 8; i++) {
                    double a = Math.toRadians(i * 45.0);
                    float sn = (float) Math.sin(a);
                    float cs = (float) Math.cos(a);
                    c.drawLine(cx + sn * s * 0.26f, cy - cs * s * 0.26f,
                            cx + sn * s * 0.38f, cy - cs * s * 0.38f, p);
                }
                break;
            default: // G_CONTROL: два переключателя
                p.setStyle(Paint.Style.STROKE);
                r.set(cx - s * 0.36f, cy - s * 0.30f, cx + s * 0.36f, cy - s * 0.06f);
                c.drawRoundRect(r, s * 0.12f, s * 0.12f, p);
                r.set(cx - s * 0.36f, cy + s * 0.06f, cx + s * 0.36f, cy + s * 0.30f);
                c.drawRoundRect(r, s * 0.12f, s * 0.12f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx + s * 0.24f, cy - s * 0.18f, s * 0.075f, p);
                c.drawCircle(cx - s * 0.24f, cy + s * 0.18f, s * 0.075f, p);
                break;
        }
    }
}
