package com.example.ioslauncher;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

/** Погода с open-meteo.com (без ключей). Обновляется не чаще раза в 30 минут. */
final class Weather {

    private static final long TTL = 30L * 60L * 1000L;
    private static volatile boolean loading = false;

    private Weather() { }

    /** Обновить погоду при необходимости. done вызывается в главном потоке. */
    static void refresh(final Cfg p, final Runnable done) {
        final int ci = p.get(Cfg.WEATHER);
        if (ci == 0 || loading) return;
        final long now = System.currentTimeMillis();
        if (p.getInt("w_city", -1) == ci && now - p.getLong("w_time", 0L) < TTL) return;
        loading = true;
        final double lat = Cfg.CITY_LAT[ci - 1];
        final double lon = Cfg.CITY_LON[ci - 1];
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String s = Net.getString("https://api.open-meteo.com/v1/forecast?latitude="
                            + lat + "&longitude=" + lon + "&current_weather=true");
                    JSONObject cw = new JSONObject(s).getJSONObject("current_weather");
                    p.putInt("w_temp", (int) Math.round(cw.getDouble("temperature") * 10.0));
                    p.putInt("w_code", cw.getInt("weathercode"));
                    p.putInt("w_city", ci);
                    p.putLong("w_time", now);
                } catch (Throwable ignored) { }
                loading = false;
                new Handler(Looper.getMainLooper()).post(done);
            }
        }).start();
    }

    /** Строка вида «Иркутск  −5°  Ясно» или пустая, если погода выключена. */
    static String line(Cfg p) {
        int ci = p.get(Cfg.WEATHER);
        if (ci == 0) return "";
        String city = Cfg.CITY_NAMES[ci - 1];
        if (p.getInt("w_city", -1) != ci || p.getLong("w_time", 0L) <= 0L) return city;
        int t = Math.round(p.getInt("w_temp", 0) / 10f);
        String sign = t > 0 ? "+" : (t < 0 ? "\u2212" : "");
        return city + "   " + sign + Math.abs(t) + "\u00B0   " + text(p.getInt("w_code", 0));
    }

    private static String text(int c) {
        if (c == 0) return "Ясно";
        if (c <= 2) return "Малооблачно";
        if (c == 3) return "Пасмурно";
        if (c == 45 || c == 48) return "Туман";
        if (c >= 51 && c <= 57) return "Морось";
        if (c >= 61 && c <= 67) return "Дождь";
        if (c >= 71 && c <= 77) return "Снег";
        if (c >= 80 && c <= 82) return "Ливень";
        if (c == 85 || c == 86) return "Снегопад";
        if (c >= 95) return "Гроза";
        return "";
    }
}
