package com.example.ioslauncher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity implements LauncherView.Host {

    private static final int DLG = android.R.style.Theme_Material_Dialog_Alert;
    private static final int ICON_PX = 128;
    private static final String DOCK = "dock";
    private static final String ORDER = "order";
    private static final String HIDDEN = "hidden";
    private static final String[] DEFAULT_DOCK = {
            "org.smarttube.stable", "org.smarttube.beta", "com.liskovsoft.smarttubetv.beta",
            "org.xbmc.kodi", "org.videolan.vlc", "com.mxtech.videoplayer.ad",
            "com.esaba.downloader", "com.example.filemanager", "com.android.tv.settings"
    };

    private static boolean autoDone = false;

    private Cfg cfg;
    private PackageManager pm;
    private float u;
    private FrameLayout root;
    private LauncherView view;
    private FrameLayout settingsOverlay;

    private volatile Bitmap mask;
    private final List<Entry> raw = new ArrayList<Entry>();
    private final List<Entry> utils = new ArrayList<Entry>();
    private String filter = "";
    private String lastSig = "";
    private boolean firstStart = true;
    private boolean longFired = false;
    private volatile boolean loading = false;

    private long ramTime = 0;
    private float ramUsedCache = 0f;
    private String ramTextCache = "";

    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { loadApps(); }
    };

    // ================================================================ старт

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = new Cfg(this);
        pm = getPackageManager();
        u = getResources().getDisplayMetrics().widthPixels / 100f;

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        view = new LauncherView(this);
        view.setHost(this);
        root.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        applyCfg();
        prepareArtAndApps();
    }

    private int px(float units) { return Math.round(units * u); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private TextView text(String s, float sizeU, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizeU * u);
        return t;
    }

    private void applyCfg() {
        view.configure(cfg.get(Cfg.ICONS), cfg.get(Cfg.LABELS) == 0, cfg.get(Cfg.ZOOM),
                cfg.get(Cfg.CLOCK), cfg.get(Cfg.FMT) == 1, cfg.get(Cfg.PERF) == 1);
    }

    // Фон, стекло и иконки готовятся в фоне, чтобы экран не ждал
    private void prepareArtAndApps() {
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap bg = Art.night(Math.max(2, dm.widthPixels / 2), Math.max(2, dm.heightPixels / 2));
                final Bitmap blur = Art.blurred(bg, 160, 90, 4);
                final Bitmap shadow = Art.shadow(ICON_PX);
                mask = Art.mask(ICON_PX);
                final List<Entry> us = new ArrayList<Entry>();
                us.add(util(Entry.U_SEARCH, "Поиск", Art.G_SEARCH, 0xFF5AC8FA, 0xFF0A6FE8));
                us.add(util(Entry.U_SETTINGS, "Настройки лаунчера", Art.G_SLIDERS, 0xFFA0A0A8, 0xFF5A5A62));
                us.add(util(Entry.U_CONTROL, "Пункт управления", Art.G_CONTROL, 0xFF6FD6FF, 0xFF5E5CE6));
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        view.setArt(bg, blur, shadow);
                        utils.clear();
                        utils.addAll(us);
                        rebuildLists();
                    }
                });
                loadAppsNow();
            }
        }).start();
    }

    private Entry util(int id, String label, int glyph, int c1, int c2) {
        Entry e = new Entry();
        e.util = id;
        e.label = label;
        e.shown = label;
        e.icon = Art.glyphIcon(glyph, ICON_PX, c1, c2, mask);
        return e;
    }

    // ============================================== приложения и списки

    private void loadApps() {
        if (loading || mask == null) return;
        new Thread(new Runnable() {
            @Override public void run() { loadAppsNow(); }
        }).start();
    }

    private void loadAppsNow() {
        if (loading) return;
        loading = true;
        final List<Entry> result = queryApps();
        runOnUiThread(new Runnable() {
            @Override public void run() {
                loading = false;
                StringBuilder sb = new StringBuilder();
                for (Entry e : result) sb.append(e.pkg).append('|').append(e.label).append(';');
                String sig = sb.toString();
                if (sig.equals(lastSig)) return;
                boolean initial = lastSig.isEmpty();
                lastSig = sig;
                raw.clear();
                raw.addAll(result);
                if (!cfg.has(DOCK)) fillDefaultDock();
                rebuildLists();
                if (initial) tryAutostart();
            }
        });
    }

    private List<Entry> queryApps() {
        List<Entry> out = new ArrayList<Entry>();
        Set<String> seen = new HashSet<String>();
        String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
        Bitmap m = mask;
        for (String cat : cats) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                Entry e = new Entry();
                e.pkg = pkg;
                e.label = String.valueOf(ri.loadLabel(pm));
                e.shown = e.label;
                e.icon = Art.iosIcon(ri.loadIcon(pm), ICON_PX, m);
                e.system = (ri.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                e.intent = new Intent(Intent.ACTION_MAIN)
                        .addCategory(cat)
                        .setComponent(new ComponentName(pkg, ri.activityInfo.name))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                out.add(e);
            }
        }
        final Collator col = Collator.getInstance();
        Collections.sort(out, new Comparator<Entry>() {
            @Override public int compare(Entry x, Entry y) { return col.compare(x.label, y.label); }
        });
        return out;
    }

    private Entry findRaw(String pkg) {
        for (Entry e : raw) if (e.pkg.equals(pkg)) return e;
        return null;
    }

    private void fillDefaultDock() {
        List<String> pins = new ArrayList<String>();
        for (String p : DEFAULT_DOCK) if (findRaw(p) != null) pins.add(p);
        for (Entry e : raw) {
            if (pins.size() >= 5) break;
            if (!pins.contains(e.pkg)) pins.add(e.pkg);
        }
        cfg.saveList(DOCK, pins);
    }

    // Видимые приложения в порядке пользователя (новые в конце по алфавиту)
    private List<Entry> visibleSorted() {
        List<String> hidden = cfg.list(HIDDEN);
        List<String> order = cfg.list(ORDER);
        List<Entry> v = new ArrayList<Entry>();
        for (Entry e : raw) if (!hidden.contains(e.pkg)) v.add(e);
        final Map<String, Integer> idx = new HashMap<String, Integer>();
        for (int i = 0; i < order.size(); i++) idx.put(order.get(i), i);
        final Collator col = Collator.getInstance();
        Collections.sort(v, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) {
                Integer ia = idx.get(a.pkg);
                Integer ib = idx.get(b.pkg);
                if (ia != null && ib != null) return ia - ib;
                if (ia != null) return -1;
                if (ib != null) return 1;
                return col.compare(a.label, b.label);
            }
        });
        return v;
    }

    private void rebuildLists() {
        List<Entry> vis = visibleSorted();
        String f = filter.toLowerCase();
        List<Entry> g = new ArrayList<Entry>();
        for (Entry e : vis) {
            if (f.isEmpty() || e.label.toLowerCase().contains(f)) g.add(e);
        }
        List<Entry> d = new ArrayList<Entry>();
        List<String> hidden = cfg.list(HIDDEN);
        for (String p : cfg.list(DOCK)) {
            Entry e = findRaw(p);
            if (e != null && !hidden.contains(p)) d.add(e);
        }
        int n = d.size();
        d.addAll(utils);
        view.setEntries(g, d, n);
    }

    private void tryAutostart() {
        if (autoDone) return;
        autoDone = true;
        if (cfg.get(Cfg.AUTOSTART) != 1) return;
        if (SystemClock.elapsedRealtime() > 180000L) return;
        for (String p : cfg.list(DOCK)) {
            Entry e = findRaw(p);
            if (e != null) {
                launch(e);
                return;
            }
        }
    }

    private void launch(Entry e) {
        if (e.intent == null) return;
        try {
            startActivity(e.intent);
        } catch (Exception ex) {
            toast("Не удалось открыть " + e.label);
        }
    }

    // ============================================================== Host

    @Override
    public void onLaunch(Entry e) {
        if (e.util == Entry.U_SEARCH) openSearch();
        else if (e.util == Entry.U_SETTINGS) openSettings();
        else if (e.util == Entry.U_CONTROL) view.openShade();
        else launch(e);
    }

    @Override
    public void onMenu(Entry e, boolean fromDock) {
        if (e.util != Entry.U_NONE) return;
        showAppMenu(e, fromDock);
    }

    @Override
    public void onTile(int id) {
        switch (id) {
            case LauncherView.T_WIFI:
                startSafe(new Intent(Settings.ACTION_WIFI_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
                break;
            case LauncherView.T_RAM:
                cleanMemory();
                break;
            case LauncherView.T_FILES:
                openPackage("com.example.filemanager", "Файловый менеджер не установлен");
                break;
            case LauncherView.T_SAVER: {
                Intent i = new Intent().setClassName("com.example.screensaver",
                        "com.example.screensaver.PreviewActivity");
                startSafe(i, null);
                break;
            }
            case LauncherView.T_SEARCH:
                openSearch();
                break;
            case LauncherView.T_ANDROID:
                startSafe(new Intent(Settings.ACTION_SETTINGS), null);
                break;
            default:
                break;
        }
    }

    private void startSafe(Intent first, Intent fallback) {
        try {
            startActivity(first);
        } catch (Exception e) {
            if (fallback == null) {
                toast("Не удалось открыть");
                return;
            }
            try { startActivity(fallback); } catch (Exception ex) { toast("Не удалось открыть"); }
        }
    }

    private void openPackage(String pkg, String missing) {
        Intent i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) toast(missing);
        else startSafe(i, null);
    }

    @Override
    public int volume() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        return max <= 0 ? 0 : am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max;
    }

    @Override
    public void setVolume(int pct) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(pct * max / 100f), 0);
    }

    // Память читается не чаще раза в 1,5 секунды (во время анимации шторки)
    private void refreshRam() {
        long now = SystemClock.elapsedRealtime();
        if (now - ramTime < 1500 && ramTime != 0) return;
        ramTime = now;
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        ramUsedCache = mi.totalMem > 0 ? 1f - (float) mi.availMem / mi.totalMem : 0f;
        double mb = mi.availMem / 1048576.0;
        ramTextCache = mb >= 1024 ? String.format(java.util.Locale.getDefault(), "%.1f ГБ", mb / 1024.0)
                : Math.round(mb) + " МБ";
    }

    @Override
    public float ramUsed() {
        refreshRam();
        return ramUsedCache;
    }

    @Override
    public String ramText() {
        refreshRam();
        return ramTextCache + " свободно";
    }

    @Override
    public String infoLine() {
        StringBuilder sb = new StringBuilder();
        if (cfg.get(Cfg.GREET) == 1) {
            int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            if (h >= 5 && h < 12) sb.append("Доброе утро");
            else if (h >= 12 && h < 18) sb.append("Добрый день");
            else if (h >= 18 && h < 23) sb.append("Добрый вечер");
            else sb.append("Доброй ночи");
        }
        String w = Weather.line(cfg);
        if (!w.isEmpty()) {
            if (sb.length() > 0) sb.append("   \u00B7   ");
            sb.append(w);
        }
        return sb.toString();
    }

    // Очистка оперативной памяти: останавливает фоновые процессы приложений
    private void cleanMemory() {
        final List<String> pkgs = new ArrayList<String>();
        for (Entry e : raw) pkgs.add(e.pkg);
        toast("Очистка памяти…");
        new Thread(new Runnable() {
            @Override public void run() {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                for (String p : pkgs) {
                    if (p.equals(getPackageName())) continue;
                    try { am.killBackgroundProcesses(p); } catch (Throwable ignored) { }
                }
                try { Thread.sleep(900); } catch (InterruptedException ignored) { }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        ramTime = 0;
                        refreshRam();
                        toast("Свободно " + ramTextCache);
                        view.invalidate();
                    }
                });
            }
        }).start();
    }

    // ================================================================ меню

    private void showAppMenu(final Entry e, final boolean fromDock) {
        final List<String> names = new ArrayList<String>();
        final List<Runnable> acts = new ArrayList<Runnable>();
        final boolean pinned = cfg.list(DOCK).contains(e.pkg);

        names.add("Открыть");
        acts.add(() -> launch(e));
        names.add(pinned ? "Убрать из дока" : "Закрепить в доке");
        acts.add(() -> togglePin(e));
        names.add("Сдвинуть влево");
        acts.add(() -> move(e, -1, fromDock));
        names.add("Сдвинуть вправо");
        acts.add(() -> move(e, 1, fromDock));
        if (!fromDock) {
            names.add("Скрыть");
            acts.add(() -> hide(e));
        }
        names.add("О приложении");
        acts.add(() -> startSafe(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + e.pkg)), null));
        if (!e.system) {
            names.add("Удалить");
            acts.add(() -> startSafe(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + e.pkg)), null));
        }
        new AlertDialog.Builder(this, DLG)
                .setTitle(e.label)
                .setItems(names.toArray(new String[0]), (d, which) -> acts.get(which).run())
                .show();
    }

    private void togglePin(Entry e) {
        List<String> pins = cfg.list(DOCK);
        if (pins.contains(e.pkg)) {
            pins.remove(e.pkg);
            toast("Убрано из дока");
        } else {
            if (pins.size() >= 8) {
                toast("В доке не больше 8 приложений");
                return;
            }
            pins.add(e.pkg);
            toast("Закреплено в доке");
        }
        cfg.saveList(DOCK, pins);
        rebuildLists();
    }

    private void move(Entry e, int dir, boolean fromDock) {
        if (fromDock) {
            List<String> pins = cfg.list(DOCK);
            int i = pins.indexOf(e.pkg);
            int j = i + dir;
            if (i < 0 || j < 0 || j >= pins.size()) {
                toast("Дальше нельзя");
                return;
            }
            Collections.swap(pins, i, j);
            cfg.saveList(DOCK, pins);
            rebuildLists();
            view.focusDock(j);
        } else {
            List<String> pk = new ArrayList<String>();
            for (Entry x : visibleSorted()) pk.add(x.pkg);
            int i = pk.indexOf(e.pkg);
            int j = i + dir;
            if (i < 0 || j < 0 || j >= pk.size()) {
                toast("Дальше нельзя");
                return;
            }
            Collections.swap(pk, i, j);
            cfg.saveList(ORDER, pk);
            rebuildLists();
            if (filter.isEmpty()) view.focusGrid(j);
        }
    }

    private void hide(Entry e) {
        List<String> hidden = cfg.list(HIDDEN);
        if (!hidden.contains(e.pkg)) hidden.add(e.pkg);
        cfg.saveList(HIDDEN, hidden);
        toast("Скрыто: " + e.label + " (вернуть: Настройки → Показать скрытые)");
        rebuildLists();
    }

    private void openSearch() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("Название приложения");
        et.setText(filter);
        et.setSelectAllOnFocus(true);
        et.setTextColor(Color.WHITE);
        et.setHintTextColor(0x66FFFFFF);
        FrameLayout fl = new FrameLayout(this);
        fl.setPadding(px(2f), px(1f), px(2f), 0);
        fl.addView(et, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this, DLG)
                .setTitle("Поиск приложений")
                .setView(fl)
                .setPositiveButton("Найти", (d, w) -> setFilter(et.getText().toString().trim()))
                .setNegativeButton("Сбросить", (d, w) -> setFilter(""))
                .show();
    }

    private void setFilter(String f) {
        filter = f;
        rebuildLists();
        view.setFilter(f);
        view.focusGrid(0);
    }

    // ============================================================ настройки

    private Drawable rowBg() {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable on = new GradientDrawable();
        on.setColor(0x44FFFFFF);
        on.setCornerRadius(1.4f * u);
        on.setStroke(Math.max(2, Math.round(0.2f * u)), 0xCCFFFFFF);
        sl.addState(new int[]{android.R.attr.state_focused}, on);
        sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return sl;
    }

    private void openSettings() {
        if (settingsOverlay != null) return;
        view.closeShade();
        settingsOverlay = new FrameLayout(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(0xEE12172E);
        pbg.setCornerRadii(new float[]{3f * u, 3f * u, 0, 0, 0, 0, 3f * u, 3f * u});
        pbg.setStroke(Math.max(1, Math.round(0.12f * u)), 0x55FFFFFF);
        panel.setBackground(pbg);
        panel.setPadding(px(2.2f), px(2.6f), px(1.6f), px(1.2f));
        TextView title = text("Настройки лаунчера", 3f, Color.WHITE);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        panel.addView(title);
        panel.addView(text("← → меняют значение, OK — следующее, Назад — закрыть", 1.3f, 0x99FFFFFF));
        panel.addView(text("Пульт: красная — поиск, зелёная — настройки, жёлтая — очистка памяти, "
                + "синяя — пункт управления", 1.2f, 0x77FFFFFF));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipToPadding(false);
        sv.setPadding(0, px(1f), px(0.5f), px(2f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        View first = null;
        for (Cfg.Opt o : Cfg.OPTS) {
            View r = optRow(o);
            if (first == null) first = r;
            list.addView(r, rowLp());
        }
        TextView sec = text("ДЕЙСТВИЯ", 1.4f, 0xFF9AA4FF);
        sec.setPadding(px(0.5f), px(1.8f), 0, px(0.4f));
        list.addView(sec);
        list.addView(actionRow("Очистить память сейчас", () -> cleanMemory()), rowLp());
        list.addView(actionRow("Сбросить док к стандартному", () -> {
            cfg.remove(DOCK);
            fillDefaultDock();
            rebuildLists();
            toast("Док сброшен");
        }), rowLp());
        list.addView(actionRow("Сбросить порядок иконок", () -> {
            cfg.remove(ORDER);
            rebuildLists();
            toast("Порядок сброшен");
        }), rowLp());
        list.addView(actionRow("Показать скрытые приложения", () -> {
            cfg.remove(HIDDEN);
            rebuildLists();
            toast("Скрытые приложения возвращены");
        }), rowLp());
        list.addView(actionRow("Обновить погоду", () -> {
            if (cfg.get(Cfg.WEATHER) == 0) toast("Сначала выберите город");
            else refreshWeather(true);
        }), rowLp());

        sv.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        settingsOverlay.addView(panel, new FrameLayout.LayoutParams(
                px(42f), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));
        root.addView(settingsOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (first != null) first.requestFocus();
    }

    private void closeSettings() {
        if (settingsOverlay == null) return;
        root.removeView(settingsOverlay);
        settingsOverlay = null;
        view.requestFocus();
    }

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = px(0.3f);
        return lp;
    }

    private View actionRow(String title, final Runnable action) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), px(1.1f), px(1.4f), px(1.1f));
        r.addView(text(title, 1.8f, Color.WHITE));
        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> action.run());
        return r;
    }

    private View optRow(final Cfg.Opt o) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(px(1.4f), px(1.1f), px(1.4f), px(1.1f));
        r.addView(text(o.title, 1.8f, Color.WHITE),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = text("", 1.8f, 0xFF9AA4FF);
        r.addView(val);
        setValueText(val, o);
        r.setFocusable(true);
        r.setClickable(true);
        r.setBackground(rowBg());
        r.setOnClickListener(x -> {
            if (o.key.equals(Cfg.WEATHER)) pickWeather(o, val);
            else changeOpt(o, val, 1);
        });
        r.setOnKeyListener((x, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) { changeOpt(o, val, 1); return true; }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) { changeOpt(o, val, -1); return true; }
            return false;
        });
        return r;
    }

    private void setValueText(TextView val, Cfg.Opt o) {
        val.setText("‹ " + o.labels[cfg.get(o.key)] + " ›");
    }

    private void changeOpt(Cfg.Opt o, TextView val, int dir) {
        int n = o.labels.length;
        applyOpt(o, val, (cfg.get(o.key) + dir + n) % n);
    }

    private void applyOpt(Cfg.Opt o, TextView val, int value) {
        cfg.set(o.key, value);
        setValueText(val, o);
        applyCfg();
        if (o.key.equals(Cfg.WEATHER)) refreshWeather(true);
        else view.refreshInfo();
    }

    // Выбор города: сначала первая буква, затем город
    private void pickWeather(final Cfg.Opt o, final TextView val) {
        TreeSet<Character> set = new TreeSet<Character>();
        for (int i = 1; i < o.labels.length; i++) set.add(o.labels[i].charAt(0));
        final List<Character> letters = new ArrayList<Character>();
        final List<String> items = new ArrayList<String>();
        items.add("Выключить погоду");
        for (Character ch : set) {
            letters.add(ch);
            items.add(String.valueOf(ch));
        }
        new AlertDialog.Builder(this, DLG)
                .setTitle("Город: первая буква")
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    if (which == 0) {
                        applyOpt(o, val, 0);
                        return;
                    }
                    final char letter = letters.get(which - 1);
                    final List<Integer> ids = new ArrayList<Integer>();
                    for (int i = 1; i < o.labels.length; i++) {
                        if (o.labels[i].charAt(0) == letter) ids.add(i);
                    }
                    Collections.sort(ids, (x, y) -> o.labels[x].compareTo(o.labels[y]));
                    String[] names = new String[ids.size()];
                    for (int k = 0; k < names.length; k++) names[k] = o.labels[ids.get(k)];
                    new AlertDialog.Builder(this, DLG)
                            .setTitle("Город на «" + letter + "»")
                            .setItems(names, (d2, w2) -> applyOpt(o, val, ids.get(w2)))
                            .show();
                })
                .show();
    }

    private void refreshWeather(boolean force) {
        if (force) cfg.putLong("w_time", 0L);
        Weather.refresh(cfg, new Runnable() {
            @Override public void run() { view.refreshInfo(); }
        });
        view.refreshInfo();
    }

    // ===================================================== клавиши пульта

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (settingsOverlay != null) return super.dispatchKeyEvent(e);
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean up = e.getAction() == KeyEvent.ACTION_UP;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (down) view.dpad(-1, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (down) view.dpad(1, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (down) view.dpad(0, -1);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (down) view.dpad(0, 1);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (down) {
                    if (e.getRepeatCount() == 0) {
                        longFired = false;
                    } else if (e.getRepeatCount() == 1 && !longFired) {
                        longFired = true;
                        view.longCenter();
                    }
                } else if (up) {
                    if (!longFired) view.center();
                    longFired = false;
                }
                return true;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_PROG_BLUE:
                if (up) view.toggleShade();
                return true;
            case KeyEvent.KEYCODE_PROG_RED:
                if (up) openSearch();
                return true;
            case KeyEvent.KEYCODE_PROG_GREEN:
                if (up) openSettings();
                return true;
            case KeyEvent.KEYCODE_PROG_YELLOW:
                if (up) cleanMemory();
                return true;
            default:
                return super.dispatchKeyEvent(e);
        }
    }

    @Override
    public void onBackPressed() {
        if (settingsOverlay != null) {
            closeSettings();
        } else if (view.back()) {
            // пункт управления закрыт
        } else if (!filter.isEmpty()) {
            setFilter("");
        }
        // на главном экране «Назад» ничего не делает
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // кнопка Home: закрыть всё и вернуться к началу
        closeSettings();
        if (!filter.isEmpty()) setFilter("");
        view.resetFocus();
        view.tick();
    }

    // ========================================================= жизненный цикл

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);
        if (!firstStart) loadApps();
        firstStart = false;
        refreshWeather(false);
        view.tick();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) { }
    }
}
