package com.example.ioslauncher;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/** Настройки лаунчера. Тема и фон фиксированные (ночной), меняется только поведение. */
final class Cfg {

    static final String ICONS = "icons", LABELS = "labels", ZOOM = "zoom", CLOCK = "clock",
            GREET = "greet", WEATHER = "weather", FMT = "fmt", PERF = "perf",
            AUTOSTART = "autostart";

    // ---- города для погоды: «название;широта;долгота» ----
    // Первые 19 остаются на своих местах, чтобы не сбился ранее выбранный город.
    private static final String CITY_DATA =
            "Алматы;43.25;76.95|" +
            "Астана;51.18;71.45|" +
            "Шымкент;42.32;69.59|" +
            "Москва;55.75;37.62|" +
            "Санкт-Петербург;59.93;30.34|" +
            "Новосибирск;55.03;82.92|" +
            "Екатеринбург;56.84;60.60|" +
            "Киев;50.45;30.52|" +
            "Минск;53.90;27.57|" +
            "Ташкент;41.30;69.24|" +
            "Бишкек;42.87;74.59|" +
            "Баку;40.41;49.87|" +
            "Тбилиси;41.72;44.79|" +
            "Ереван;40.18;44.51|" +
            "Стамбул;41.01;28.98|" +
            "Дубай;25.20;55.27|" +
            "Берлин;52.52;13.41|" +
            "Лондон;51.51;-0.13|" +
            "Нью-Йорк;40.71;-74.01|" +
            "Абакан;53.72;91.44|" +
            "Анадырь;64.73;177.51|" +
            "Ангарск;52.54;103.89|" +
            "Архангельск;64.54;40.54|" +
            "Астрахань;46.35;48.04|" +
            "Барнаул;53.35;83.78|" +
            "Белгород;50.60;36.59|" +
            "Биробиджан;48.79;132.92|" +
            "Благовещенск;50.28;127.53|" +
            "Братск;56.15;101.63|" +
            "Брянск;53.24;34.36|" +
            "Великий Новгород;58.52;31.27|" +
            "Владивосток;43.12;131.89|" +
            "Владикавказ;43.02;44.68|" +
            "Владимир;56.13;40.41|" +
            "Волгоград;48.71;44.51|" +
            "Вологда;59.22;39.89|" +
            "Воронеж;51.66;39.20|" +
            "Гатчина;59.58;30.13|" +
            "Горно-Алтайск;51.96;85.96|" +
            "Грозный;43.32;45.70|" +
            "Донецк;48.00;37.80|" +
            "Иваново;57.00;40.97|" +
            "Ижевск;56.85;53.20|" +
            "Иркутск;52.29;104.30|" +
            "Йошкар-Ола;56.63;47.89|" +
            "Казань;55.79;49.12|" +
            "Калининград;54.71;20.51|" +
            "Калуга;54.51;36.26|" +
            "Кемерово;55.35;86.09|" +
            "Киров;58.60;49.66|" +
            "Кострома;57.77;40.93|" +
            "Краснодар;45.04;38.98|" +
            "Красногорск;55.82;37.33|" +
            "Красноярск;56.01;92.85|" +
            "Курган;55.44;65.34|" +
            "Курск;51.73;36.19|" +
            "Кызыл;51.72;94.44|" +
            "Липецк;52.61;39.60|" +
            "Луганск;48.57;39.31|" +
            "Магадан;59.56;150.80|" +
            "Магас;43.17;44.81|" +
            "Майкоп;44.61;40.10|" +
            "Махачкала;42.98;47.50|" +
            "Мелитополь;46.85;35.37|" +
            "Мурманск;68.97;33.09|" +
            "Нальчик;43.49;43.62|" +
            "Нарьян-Мар;67.64;53.00|" +
            "Нижний Новгород;56.33;44.00|" +
            "Норильск;69.35;88.20|" +
            "Омск;54.99;73.37|" +
            "Оренбург;51.77;55.10|" +
            "Орёл;52.97;36.06|" +
            "Пенза;53.20;45.00|" +
            "Пермь;58.01;56.25|" +
            "Петрозаводск;61.79;34.39|" +
            "Петропавловск-Камчатский;53.04;158.65|" +
            "Псков;57.82;28.33|" +
            "Ростов-на-Дону;47.24;39.71|" +
            "Рязань;54.63;39.74|" +
            "Салехард;66.53;66.60|" +
            "Самара;53.20;50.16|" +
            "Саранск;54.19;45.18|" +
            "Саратов;51.54;46.01|" +
            "Севастополь;44.62;33.52|" +
            "Симферополь;44.95;34.10|" +
            "Смоленск;54.78;32.05|" +
            "Сочи;43.60;39.73|" +
            "Ставрополь;45.04;41.97|" +
            "Сургут;61.25;73.40|" +
            "Сыктывкар;61.67;50.81|" +
            "Тамбов;52.72;41.45|" +
            "Тверь;56.86;35.90|" +
            "Томск;56.48;84.95|" +
            "Тула;54.19;37.62|" +
            "Тюмень;57.15;65.53|" +
            "Улан-Удэ;51.83;107.61|" +
            "Ульяновск;54.32;48.39|" +
            "Уфа;54.74;55.97|" +
            "Хабаровск;48.48;135.08|" +
            "Ханты-Мансийск;61.00;69.00|" +
            "Херсон;46.64;32.62|" +
            "Чебоксары;56.13;47.25|" +
            "Челябинск;55.16;61.40|" +
            "Черкесск;44.22;42.06|" +
            "Чита;52.03;113.50|" +
            "Элиста;46.31;44.26|" +
            "Южно-Сахалинск;46.96;142.73|" +
            "Якутск;62.03;129.73|" +
            "Ярославль;57.63;39.87";

    static final String[] CITY_NAMES;
    static final double[] CITY_LAT;
    static final double[] CITY_LON;

    static {
        String[] rows = CITY_DATA.split("\\|");
        CITY_NAMES = new String[rows.length];
        CITY_LAT = new double[rows.length];
        CITY_LON = new double[rows.length];
        for (int i = 0; i < rows.length; i++) {
            String[] p = rows[i].split(";");
            CITY_NAMES[i] = p[0];
            CITY_LAT[i] = Double.parseDouble(p[1]);
            CITY_LON[i] = Double.parseDouble(p[2]);
        }
    }


    static final class Opt {
        final String key;
        final String title;
        final int def;
        final String[] labels;

        Opt(String key, String title, int def, String... labels) {
            this.key = key;
            this.title = title;
            this.def = def;
            this.labels = labels;
        }
    }

    private static String[] withOff(String[] names) {
        String[] r = new String[names.length + 1];
        r[0] = "Выкл";
        System.arraycopy(names, 0, r, 1, names.length);
        return r;
    }

    static final Opt[] OPTS = {
            new Opt(ICONS, "Размер иконок", 1, "Мелкие", "Средние", "Крупные"),
            new Opt(LABELS, "Подписи под иконками", 0, "Показывать", "Скрыть"),
            new Opt(ZOOM, "Увеличение иконок в доке", 0, "Сильное", "Слабое", "Выкл"),
            new Opt(CLOCK, "Часы", 0, "Вытянутые (высокие)", "Широкие", "Обычные", "Скрыть"),
            new Opt(FMT, "Формат времени", 0, "24 часа", "12 часов"),
            new Opt(GREET, "Приветствие", 1, "Выкл", "Вкл"),
            new Opt(WEATHER, "Погода", 0, withOff(CITY_NAMES)),
            new Opt(PERF, "Режим производительности", 0, "Обычный", "Лёгкий"),
            new Opt(AUTOSTART, "Автозапуск при включении", 0, "Выкл", "Первое в доке")
    };

    private final SharedPreferences sp;

    Cfg(Context c) {
        sp = c.getSharedPreferences("glass_prefs", Context.MODE_PRIVATE);
    }

    int get(String key) {
        for (Opt o : OPTS) {
            if (o.key.equals(key)) {
                return Math.max(0, Math.min(o.labels.length - 1, sp.getInt(key, o.def)));
            }
        }
        return sp.getInt(key, 0);
    }

    void set(String key, int v) { sp.edit().putInt(key, v).apply(); }

    int getInt(String key, int def) { return sp.getInt(key, def); }

    void putInt(String key, int v) { sp.edit().putInt(key, v).apply(); }

    long getLong(String key, long def) { return sp.getLong(key, def); }

    void putLong(String key, long v) { sp.edit().putLong(key, v).apply(); }

    boolean has(String key) { return sp.contains(key); }

    void remove(String key) { sp.edit().remove(key).apply(); }

    // Списки (док, порядок, скрытые): пакеты через перевод строки
    List<String> list(String key) {
        String s = sp.getString(key, "");
        List<String> l = new ArrayList<String>();
        if (s != null && !s.isEmpty()) {
            for (String x : s.split("\n")) {
                if (!x.isEmpty()) l.add(x);
            }
        }
        return l;
    }

    void saveList(String key, List<String> l) {
        sp.edit().putString(key, TextUtils.join("\n", l)).apply();
    }

    void resetOptions() {
        SharedPreferences.Editor e = sp.edit();
        for (Opt o : OPTS) e.remove(o.key);
        e.apply();
    }
}
