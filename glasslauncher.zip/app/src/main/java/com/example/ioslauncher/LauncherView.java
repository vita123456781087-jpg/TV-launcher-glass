package com.example.ioslauncher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Весь главный экран рисуется одним View: часы, сетка иконок, док как на Mac и пункт
 * управления. Фон, размытие и иконки подготовлены заранее, поэтому на кадр уходит
 * лишь несколько вызовов drawBitmap. Когда ничего не движется, экран не перерисовывается.
 */
final class LauncherView extends View {

    interface Host {
        void onLaunch(Entry e);
        void onMenu(Entry e, boolean fromDock);
        void onTile(int id);
        int volume();
        void setVolume(int pct);
        float ramUsed();
        String ramText();
        String infoLine();
    }

    // плитки пункта управления
    static final int T_VOLUME = 1, T_WIFI = 2, T_RAM = 3, T_FILES = 4, T_SAVER = 5,
            T_SEARCH = 6, T_ANDROID = 7;
    private static final int[] TILE_ID = {T_VOLUME, T_WIFI, T_RAM, T_FILES, T_SAVER, T_SEARCH, T_ANDROID};
    private static final int[] TILE_COL = {0, 2, 3, 0, 1, 2, 3};
    private static final int[] TILE_ROW = {0, 0, 0, 1, 1, 1, 1};
    private static final int[] TILE_SPAN = {2, 1, 1, 1, 1, 1, 1};
    // соседи плитки: влево, вправо, вверх, вниз
    private static final int[][] TILE_NAV = {
            {-1, 1, -1, 3}, {0, 2, -1, 5}, {1, -1, -1, 6}, {-1, 4, 0, -1},
            {3, 5, 0, -1}, {4, 6, 1, -1}, {5, -1, 2, -1}};
    private static final String[] TILE_LABEL = {
            "Громкость", "Сеть", "Память", "Файлы", "Заставка", "Поиск", "Настройки"};
    private static final int[] TILE_GLYPH = {
            Art.G_VOLUME, Art.G_WIFI, Art.G_RAM, Art.G_FOLDER, Art.G_MOON, Art.G_SEARCH, Art.G_COG};

    private Host host;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private List<Entry> grid = new ArrayList<Entry>();
    private List<Entry> dock = new ArrayList<Entry>();
    private int dockApps = 0;

    private Bitmap bg;
    private Bitmap shadowBmp;
    private BitmapShader blurShader;
    private final Matrix shaderM = new Matrix();

    // ---- настройки вида ----
    private int iconIdx = 1;
    private boolean labels = true;
    private float dockMag = 0.55f;
    private int clockStyle = 0;
    private boolean h12 = false;
    private boolean light = false;
    private String filterText = "";

    // ---- кисти ----
    private final Paint bgP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint iconP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowP = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint glassP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint tintP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hiP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelBoldP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint timeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dateP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tipP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint scrimP = new Paint();
    private final Paint glyphP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private final RectF tmp2 = new RectF();
    private final Rect dstFull = new Rect();

    // ---- геометрия ----
    private float W, H, u;
    private float iconSize, colW, rowH, gridLeft, gridTop, gridClipBottom;
    private int cols = 7;
    private float dockIcon, dockGap, dockPad, dockBottom, sepGap;
    private float[] dockCx0 = new float[0];
    private final RectF[] dockRects = new RectF[32];
    private float timeBase, dateY, timeX, sx = 1f, sy = 1f;
    private final RectF[] tileRects = new RectF[7];
    private final RectF panelRect = new RectF();

    // ---- время ----
    private String timeStr = "";
    private String headLine = "";
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault());

    // ---- состояние и анимации ----
    private int zone = 0;       // 0 сетка, 1 док, 2 пункт управления
    private int zoneBefore = 0;
    private int gi = 0;
    private int di = 0;
    private int si = 0;
    private int prevGi = -1;
    private float scrollY = 0f, scrollTarget = 0f;
    private float dockPos = 0f, dockAmt = 0f;
    private float gridFocusP = 1f;
    private float shadeP = 0f, shadeTarget = 0f;
    private long lastFrame = 0;

    LauncherView(Context c) {
        super(c);
        setFocusable(true);
        for (int i = 0; i < dockRects.length; i++) dockRects[i] = new RectF();
        for (int i = 0; i < tileRects.length; i++) tileRects[i] = new RectF();

        labelP.setTextAlign(Paint.Align.CENTER);
        labelP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        labelP.setColor(0xD9FFFFFF);
        labelBoldP.setTextAlign(Paint.Align.CENTER);
        labelBoldP.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        labelBoldP.setColor(0xFFFFFFFF);
        timeP.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        dateP.setTextAlign(Paint.Align.CENTER);
        dateP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        dateP.setLetterSpacing(0.12f);
        dateP.setColor(0xCCFFFFFF);
        tipP.setTextAlign(Paint.Align.CENTER);
        tipP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tipP.setColor(0xFFFFFFFF);
        edgeP.setStyle(Paint.Style.STROKE);
        hiP.setStyle(Paint.Style.STROKE);
        hiP.setStrokeCap(Paint.Cap.ROUND);
        glassP.setColor(0xFFFFFFFF);
        scrimP.setColor(0xFF000000);
        barP.setStyle(Paint.Style.FILL);
    }

    void setHost(Host h) { host = h; }

    void setArt(Bitmap bg, Bitmap blur, Bitmap shadow) {
        this.bg = bg;
        this.shadowBmp = shadow;
        blurShader = blur == null ? null : new BitmapShader(blur, Shader.TileMode.CLAMP,
                Shader.TileMode.CLAMP);
        if (blurShader != null && W > 0) {
            shaderM.setScale(W / blur.getWidth(), H / blur.getHeight());
            blurShader.setLocalMatrix(shaderM);
        }
        invalidate();
    }

    void setEntries(List<Entry> grid, List<Entry> dock, int dockApps) {
        this.grid = grid;
        this.dock = dock;
        this.dockApps = dockApps;
        gi = Math.max(0, Math.min(gi, Math.max(0, grid.size() - 1)));
        di = Math.max(0, Math.min(di, Math.max(0, dock.size() - 1)));
        relayout();
        invalidate();
    }

    void configure(int iconIdx, boolean labels, int zoomIdx, int clockStyle, boolean h12,
                   boolean light) {
        this.iconIdx = iconIdx;
        this.labels = labels;
        this.dockMag = zoomIdx == 0 ? 0.55f : (zoomIdx == 1 ? 0.25f : 0f);
        this.clockStyle = clockStyle;
        this.h12 = h12;
        this.light = light;
        relayout();
        tick();
    }

    void setFilter(String f) {
        filterText = f == null ? "" : f;
        refreshInfo();
    }

    void resetFocus() {
        zone = 0;
        gi = 0;
        scrollTarget = 0;
        scrollY = 0;
        shadeTarget = 0;
        shadeP = 0;
        prevGi = -1;
        invalidate();
    }

    boolean shadeOpen() { return zone == 2; }

    /** Поставить фокус на иконку сетки (после перестановки). */
    void focusGrid(int idx) {
        zone = 0;
        gi = Math.max(0, Math.min(idx, Math.max(0, grid.size() - 1)));
        prevGi = -1;
        gridFocusP = 0f;
        ensureVisible();
        invalidate();
    }

    /** Поставить фокус на иконку дока. */
    void focusDock(int idx) {
        zone = 1;
        di = Math.max(0, Math.min(idx, Math.max(0, dock.size() - 1)));
        dockPos = di;
        invalidate();
    }

    // ------------------------------------------------------------- размеры

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w;
        H = h;
        dstFull.set(0, 0, w, h);
        relayout();
    }

    private String fit(String s, Paint p, float max) {
        if (p.measureText(s) <= max) return s;
        int n = s.length();
        while (n > 1 && p.measureText(s, 0, n) + p.measureText("…") > max) n--;
        return s.substring(0, n) + "…";
    }

    private void relayout() {
        if (W <= 0 || H <= 0) return;
        u = Math.min(W / 100f, H / 56.25f);

        float[] sizes = {7.4f, 8.6f, 9.8f};
        int[] colsBy = {8, 7, 6};
        iconSize = sizes[iconIdx] * u;
        cols = colsBy[iconIdx];
        colW = W * 0.88f / cols;
        gridLeft = W * 0.06f;
        gridTop = H * 0.345f;
        gridClipBottom = H - dockIconBase() - dockPadBase() * 2 - 4.2f * u;
        float labelH = labels ? 3.6f * u : 0f;
        rowH = iconSize + labelH + 2.4f * u;

        labelP.setTextSize(Math.max(12f, 1.55f * u));
        labelBoldP.setTextSize(Math.max(12f, 1.55f * u));
        for (Entry e : grid) e.shown = fit(e.label, labelP, colW * 0.96f);

        // док
        dockIcon = dockIconBase();
        dockGap = 1.1f * u;
        dockPad = dockPadBase();
        dockBottom = H - 2.2f * u;
        sepGap = 1.6f * u;
        tipP.setTextSize(Math.max(12f, 1.7f * u));
        int n = dock.size();
        dockCx0 = new float[n];
        float total = n * dockIcon + Math.max(0, n - 1) * dockGap + sepExtra();
        float x = (W - total) / 2f;
        for (int i = 0; i < n; i++) {
            if (i == dockApps && dockApps > 0 && dockApps < n) x += sepExtra();
            dockCx0[i] = x + dockIcon / 2f;
            x += dockIcon + dockGap;
        }

        // часы
        float capTarget;
        if (clockStyle == 0) { capTarget = 0.18f; sx = 0.95f; sy = 1.5f; }
        else if (clockStyle == 1) { capTarget = 0.12f; sx = 1.8f; sy = 1f; }
        else { capTarget = 0.12f; sx = 1f; sy = 1f; }
        timeP.setTextSize(100f);
        Rect b = new Rect();
        timeP.getTextBounds("0", 0, 1, b);
        float capRatio = b.height() / 100f;
        float size = capTarget * H / (capRatio * sy);
        timeP.setTextSize(size);
        float cap = capRatio * size;
        timeP.setShader(new LinearGradient(0, -cap, 0, 0, 0xFFFFFFFF, 0x99FFFFFF,
                Shader.TileMode.CLAMP));
        dateY = H * 0.085f;
        timeBase = H * 0.12f + capTarget * H;
        dateP.setTextSize(Math.max(12f, 1.9f * u));

        // пункт управления
        float pw = W * 0.72f;
        float ph = H * 0.56f;
        float px = (W - pw) / 2f;
        float pad = 2.2f * u;
        float gap = 1.4f * u;
        float headH = 4.5f * u;
        float tw = (pw - 2 * pad - 3 * gap) / 4f;
        float th = (ph - headH - 2 * pad - gap) / 2f;
        panelRect.set(px, 0, px + pw, ph);
        for (int i = 0; i < 7; i++) {
            float left = px + pad + TILE_COL[i] * (tw + gap);
            float top = pad + headH + TILE_ROW[i] * (th + gap);
            tileRects[i].set(left, top, left + tw * TILE_SPAN[i] + gap * (TILE_SPAN[i] - 1), top + th);
        }

        if (blurShader != null && bg != null) {
            // размытая копия растягивается на весь экран
            shaderM.setScale(W / Math.max(1, blurW), H / Math.max(1, blurH));
            blurShader.setLocalMatrix(shaderM);
        }
        ensureVisible();
        scrollY = scrollTarget;
        refreshInfo(); // пересчитать положение времени после смены размеров
    }

    private int blurW = 160;
    private int blurH = 90;

    void setBlurSize(int w, int h) {
        blurW = w;
        blurH = h;
    }

    private float dockIconBase() { return 6.4f * u; }

    private float dockPadBase() { return 1.4f * u; }

    private float sepExtra() {
        return (dockApps > 0 && dockApps < dock.size()) ? sepGap : 0f;
    }

    // ---------------------------------------------------------------- время

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        tick();
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }

    private final Runnable tickTask = new Runnable() {
        @Override public void run() { tick(); }
    };

    /** Обновляет строки времени и даты, затем ждёт следующей минуты. */
    void tick() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        if (h12) {
            hour = hour % 12;
            if (hour == 0) hour = 12;
            timeStr = hour + ":" + (min < 10 ? "0" : "") + min;
        } else {
            timeStr = (hour < 10 ? "0" : "") + hour + ":" + (min < 10 ? "0" : "") + min;
        }
        refreshInfo();
        handler.removeCallbacks(tickTask);
        long now = System.currentTimeMillis();
        handler.postDelayed(tickTask, 60000L - (now % 60000L) + 200L);
    }

    /** Пересобирает верхнюю строку (дата, приветствие, погода или поиск). */
    void refreshInfo() {
        if (W <= 0) return;
        String date = dateFmt.format(new Date()).toUpperCase(Locale.getDefault());
        String info = host == null ? "" : host.infoLine();
        if (!filterText.isEmpty()) {
            headLine = "ПОИСК: " + filterText.toUpperCase(Locale.getDefault());
        } else {
            headLine = info.isEmpty() ? date : date + "   \u00B7   " + info;
        }
        timeX = (W - timeP.measureText(timeStr) * sx) / 2f;
        invalidate();
    }

    // ------------------------------------------------------------ анимация

    private static float ease(float t) {
        return t * t * (3f - 2f * t);
    }

    private void kick() {
        invalidate();
    }

    private boolean step(float dt) {
        float speed = light ? 22f : 14f;
        float k = 1f - (float) Math.exp(-dt * speed);
        boolean more = false;

        scrollY += (scrollTarget - scrollY) * k;
        if (Math.abs(scrollTarget - scrollY) < 0.5f) scrollY = scrollTarget;
        else more = true;

        dockPos += (di - dockPos) * k;
        if (Math.abs(di - dockPos) < 0.01f) dockPos = di;
        else more = true;

        float da = zone == 1 ? 1f : 0f;
        dockAmt += (da - dockAmt) * k;
        if (Math.abs(da - dockAmt) < 0.01f) dockAmt = da;
        else more = true;

        if (gridFocusP < 1f) {
            gridFocusP = Math.min(1f, gridFocusP + dt / (light ? 0.08f : 0.16f));
            if (gridFocusP < 1f) more = true;
        }

        shadeP += (shadeTarget - shadeP) * (1f - (float) Math.exp(-dt * 12f));
        if (Math.abs(shadeTarget - shadeP) < 0.01f) shadeP = shadeTarget;
        else more = true;
        return more;
    }

    // ------------------------------------------------------------- рисование

    @Override
    protected void onDraw(Canvas c) {
        if (W <= 0) return;
        long now = System.nanoTime();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1e9f);
        lastFrame = now;
        boolean more = step(dt);

        if (bg != null) c.drawBitmap(bg, null, dstFull, bgP);
        drawClock(c);
        drawGrid(c);
        drawDock(c);
        if (shadeP > 0.001f) drawShade(c);

        if (more) postInvalidateOnAnimation();
        else lastFrame = 0;
    }

    // Панель «матового стекла»: размытый фон, лёгкая заливка, рамка и блик сверху
    private void glass(Canvas c, RectF r, float rad, int tint) {
        if (!light && blurShader != null) {
            glassP.setShader(blurShader);
            c.drawRoundRect(r, rad, rad, glassP);
            glassP.setShader(null);
        }
        tintP.setColor(tint);
        c.drawRoundRect(r, rad, rad, tintP);
        edgeP.setStrokeWidth(Math.max(1.2f, u * 0.12f));
        edgeP.setColor(0x66FFFFFF);
        c.drawRoundRect(r, rad, rad, edgeP);
        hiP.setStrokeWidth(Math.max(1.2f, u * 0.1f));
        hiP.setColor(0x55FFFFFF);
        c.drawLine(r.left + rad * 0.9f, r.top + 1.6f, r.right - rad * 0.9f, r.top + 1.6f, hiP);
    }

    private void drawClock(Canvas c) {
        c.drawText(headLine, W / 2f, dateY, dateP);
        if (clockStyle == 3) return;
        c.save();
        c.translate(timeX, timeBase);
        c.scale(sx, sy);
        c.drawText(timeStr, 0, 0, timeP);
        c.restore();
    }

    private void drawIcon(Canvas c, Bitmap b, float cx, float cy, float size) {
        tmp.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f);
        c.drawBitmap(b, null, tmp, iconP);
    }

    private void drawShadow(Canvas c, float cx, float cy, float size, int alpha) {
        if (light || shadowBmp == null || alpha <= 0) return;
        float s = size * 1.5f;
        tmp.set(cx - s / 2f, cy + size * 0.10f - s / 2f, cx + s / 2f, cy + size * 0.10f + s / 2f);
        shadowP.setAlpha(Math.min(255, alpha));
        c.drawBitmap(shadowBmp, null, tmp, shadowP);
    }

    private void drawGrid(Canvas c) {
        int n = grid.size();
        if (n == 0) {
            c.drawText("Загрузка приложений…", W / 2f, gridTop + 6 * u, dateP);
            return;
        }
        c.save();
        c.clipRect(0, gridTop - 2.2f * u, W, gridClipBottom);
        float e = ease(gridFocusP);
        for (int i = 0; i < n; i++) {
            int r = i / cols;
            float top = gridTop + r * rowH - scrollY;
            if (top + rowH < gridTop - 3 * u || top > gridClipBottom) continue;
            float cx = gridLeft + (i % cols + 0.5f) * colW;
            float cy = top + iconSize / 2f;

            float pop = 0f;
            if (i == gi) pop = zone == 0 ? e : (1f - e);
            else if (i == prevGi && gridFocusP < 1f) pop = 1f - e;
            boolean focused = zone == 0 && i == gi;
            float size = iconSize * (1f + 0.16f * pop);

            drawShadow(c, cx, cy, size, (int) (200 * pop));
            drawIcon(c, grid.get(i).icon, cx, cy, size);
            if (pop > 0.05f) {
                edgeP.setStrokeWidth(Math.max(2f, size * 0.022f));
                edgeP.setColor(((int) (0xCC * pop) << 24) | 0x00FFFFFF);
                tmp.inset(-size * 0.035f, -size * 0.035f);
                c.drawRoundRect(tmp, size * 0.27f, size * 0.27f, edgeP);
            }
            if (labels) {
                float ly = top + iconSize + 2.2f * u + (iconSize * 0.16f) * pop;
                c.drawText(grid.get(i).shown, cx, ly, focused ? labelBoldP : labelP);
            }
        }
        c.restore();
    }

    private static float gauss(float d) {
        return (float) Math.exp(-d * d / 0.8f);
    }

    private void drawDock(Canvas c) {
        int n = dock.size();
        if (n == 0) return;
        float amt = dockAmt;
        float[] scl = new float[n];
        float total = Math.max(0, n - 1) * dockGap + sepExtra();
        for (int i = 0; i < n; i++) {
            scl[i] = 1f + dockMag * gauss(Math.abs(i - dockPos)) * amt;
            total += dockIcon * scl[i];
        }
        float x = (W - total) / 2f;
        float baseline = dockBottom - dockPad;

        // подложка дока
        float pillH = dockIcon + 2 * dockPad;
        tmp2.set(x - dockPad * 1.4f, dockBottom - pillH, x + total + dockPad * 1.4f, dockBottom);
        glass(c, tmp2, pillH * 0.34f, 0x30FFFFFF);

        float sepX = -1;
        for (int i = 0; i < n; i++) {
            if (i == dockApps && dockApps > 0 && dockApps < n) {
                sepX = x + sepGap / 2f - dockGap / 2f;
                x += sepGap;
            }
            float w = dockIcon * scl[i];
            float cx = x + w / 2f;
            float cy = baseline - w / 2f;
            dockRects[Math.min(i, dockRects.length - 1)].set(cx - w / 2f, cy - w / 2f, cx + w / 2f, cy + w / 2f);
            if (scl[i] > 1.02f) drawShadow(c, cx, cy, w, (int) (140 * (scl[i] - 1f) / Math.max(0.01f, dockMag)));
            drawIcon(c, dock.get(i).icon, cx, cy, w);
            x += w + dockGap;
        }
        if (sepX > 0) {
            hiP.setStrokeWidth(Math.max(1.5f, u * 0.14f));
            hiP.setColor(0x55FFFFFF);
            c.drawLine(sepX, dockBottom - pillH + dockPad, sepX, dockBottom - dockPad, hiP);
        }

        // всплывающая подпись над выбранной иконкой (как в macOS)
        if (zone == 1 && amt > 0.5f && di < dock.size()) {
            RectF r = dockRects[Math.min(di, dockRects.length - 1)];
            String t = dock.get(di).label;
            float tw = tipP.measureText(t) + 3f * u;
            float th = 3.6f * u;
            float tx = r.centerX();
            float ty = r.top - 1.2f * u;
            tmp2.set(tx - tw / 2f, ty - th, tx + tw / 2f, ty);
            if (tmp2.left < u) tmp2.offset(u - tmp2.left, 0);
            if (tmp2.right > W - u) tmp2.offset(W - u - tmp2.right, 0);
            glass(c, tmp2, th / 2f, 0x40000000);
            Paint.FontMetrics fm = tipP.getFontMetrics();
            c.drawText(t, tmp2.centerX(), tmp2.centerY() - (fm.ascent + fm.descent) / 2f, tipP);
        }
    }

    // Пункт управления: опускается сверху, внутри плитки из стекла
    private void drawShade(Canvas c) {
        float p = ease(shadeP);
        scrimP.setAlpha((int) (0x99 * p));
        c.drawRect(0, 0, W, H, scrimP);

        float dy = -panelRect.height() + (panelRect.height() + H * 0.05f) * p;
        c.save();
        c.translate(0, dy);
        glass(c, panelRect, 3.2f * u, 0x30FFFFFF);

        tipP.setTextAlign(Paint.Align.LEFT);
        tipP.setTextSize(Math.max(14f, 2.2f * u));
        c.drawText("Пункт управления", panelRect.left + 2.4f * u, 4.2f * u, tipP);
        tipP.setTextAlign(Paint.Align.CENTER);

        for (int i = 0; i < 7; i++) drawTile(c, i);
        c.restore();
    }

    private void drawTile(Canvas c, int i) {
        RectF r = tileRects[i];
        boolean sel = zone == 2 && si == i;
        tintP.setColor(sel ? 0x55FFFFFF : 0x26FFFFFF);
        c.drawRoundRect(r, 2f * u, 2f * u, tintP);
        edgeP.setStrokeWidth(Math.max(1.2f, u * (sel ? 0.22f : 0.1f)));
        edgeP.setColor(sel ? 0xDDFFFFFF : 0x44FFFFFF);
        c.drawRoundRect(r, 2f * u, 2f * u, edgeP);

        float gs = r.height() * 0.42f;
        float gx = r.left + 0.8f * u + gs / 2f;
        float gy = r.top + 0.8f * u + gs / 2f;
        Art.glyph(c, glyphP, TILE_GLYPH[i], gx, gy, gs, 0xFFFFFFFF, Math.max(2f, gs * 0.07f));

        labelP.setTextAlign(Paint.Align.LEFT);
        labelP.setTextSize(Math.max(12f, 1.6f * u));
        c.drawText(TILE_LABEL[i], r.left + 1.2f * u, r.bottom - 1.2f * u, labelP);
        labelP.setTextAlign(Paint.Align.CENTER);

        if (TILE_ID[i] == T_VOLUME && host != null) {
            int v = host.volume();
            float bx = r.left + 1.2f * u;
            float bw = r.width() - 2.4f * u;
            float by = r.centerY() + 0.4f * u;
            float bh = Math.max(6f, 0.9f * u);
            barP.setColor(0x44FFFFFF);
            tmp2.set(bx, by, bx + bw, by + bh);
            c.drawRoundRect(tmp2, bh / 2f, bh / 2f, barP);
            barP.setColor(0xFFFFFFFF);
            tmp2.set(bx, by, bx + Math.max(bh, bw * v / 100f), by + bh);
            c.drawRoundRect(tmp2, bh / 2f, bh / 2f, barP);
            tipP.setTextAlign(Paint.Align.RIGHT);
            tipP.setTextSize(Math.max(12f, 1.8f * u));
            c.drawText(v + "%", r.right - 1.2f * u, r.top + 3.2f * u, tipP);
            tipP.setTextAlign(Paint.Align.CENTER);
        } else if (TILE_ID[i] == T_RAM && host != null) {
            tipP.setTextAlign(Paint.Align.RIGHT);
            tipP.setTextSize(Math.max(11f, 1.5f * u));
            c.drawText(host.ramText(), r.right - 1.0f * u, r.top + 2.8f * u, tipP);
            tipP.setTextAlign(Paint.Align.CENTER);
            float used = host.ramUsed();
            float bh = Math.max(5f, 0.7f * u);
            float bx = r.left + 1.2f * u;
            float bw = r.width() - 2.4f * u;
            float by = r.centerY() + 0.8f * u;
            barP.setColor(0x44FFFFFF);
            tmp2.set(bx, by, bx + bw, by + bh);
            c.drawRoundRect(tmp2, bh / 2f, bh / 2f, barP);
            barP.setColor(used < 0.6f ? 0xFF4ADE80 : (used < 0.8f ? 0xFFFBBF24 : 0xFFF87171));
            tmp2.set(bx, by, bx + Math.max(bh, bw * used), by + bh);
            c.drawRoundRect(tmp2, bh / 2f, bh / 2f, barP);
        }
    }

    // ------------------------------------------------------------ управление

    private void ensureVisible() {
        int n = grid.size();
        int rows = (n + cols - 1) / cols;
        float areaH = gridClipBottom - gridTop;
        float top = (gi / cols) * rowH;
        float bottom = top + rowH;
        if (top < scrollTarget) scrollTarget = top;
        else if (bottom > scrollTarget + areaH) scrollTarget = bottom - areaH;
        float max = Math.max(0f, rows * rowH - areaH);
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget));
    }

    private int nearestDock(float x) {
        int best = 0;
        float bd = Float.MAX_VALUE;
        for (int i = 0; i < dockCx0.length; i++) {
            float d = Math.abs(dockCx0[i] - x);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    void dpad(int dx, int dy) {
        if (zone == 2) {
            shadeNav(dx, dy);
        } else if (zone == 0) {
            gridNav(dx, dy);
        } else {
            dockNav(dx, dy);
        }
        kick();
    }

    private void gridNav(int dx, int dy) {
        int n = grid.size();
        if (n == 0) {
            if (dy < 0) openShade();
            else if (dy > 0) enterDock();
            return;
        }
        int old = gi;
        if (dx < 0) {
            if (gi > 0) gi--;
        } else if (dx > 0) {
            if (gi < n - 1) gi++;
        } else if (dy < 0) {
            if (gi >= cols) gi -= cols;
            else {
                openShade();
                return;
            }
        } else if (dy > 0) {
            int lastRow = (n - 1) / cols;
            if (gi / cols < lastRow) gi = Math.min(n - 1, gi + cols);
            else {
                enterDock();
                return;
            }
        }
        if (gi != old) {
            prevGi = old;
            gridFocusP = 0f;
            ensureVisible();
        }
    }

    private void enterDock() {
        if (dock.isEmpty()) return;
        prevGi = gi;
        gridFocusP = 0f;
        zone = 1;
        float cx = gridLeft + (gi % cols + 0.5f) * colW;
        di = nearestDock(cx);
        dockPos = di;
    }

    private void dockNav(int dx, int dy) {
        if (dy < 0) {
            zone = 0;
            prevGi = -1;
            gridFocusP = 0f;
            return;
        }
        if (dx < 0 && di > 0) di--;
        else if (dx > 0 && di < dock.size() - 1) di++;
    }

    private void shadeNav(int dx, int dy) {
        if (si == 0 && dx != 0 && host != null) { // громкость: влево/вправо меняют уровень
            host.setVolume(Math.max(0, Math.min(100, host.volume() + dx * 6)));
            return;
        }
        int[] nav = TILE_NAV[si];
        int t = dx < 0 ? nav[0] : (dx > 0 ? nav[1] : (dy < 0 ? nav[2] : nav[3]));
        if (t >= 0) si = t;
        else if (dy < 0) closeShade();
    }

    void openShade() {
        if (zone == 2) return;
        zoneBefore = zone;
        zone = 2;
        si = 0;
        shadeTarget = 1f;
        kick();
    }

    void closeShade() {
        if (zone != 2) return;
        zone = zoneBefore;
        shadeTarget = 0f;
        gridFocusP = 0f;
        kick();
    }

    void toggleShade() {
        if (zone == 2) closeShade();
        else openShade();
    }

    /** Нажатие OK. */
    void center() {
        if (host == null) return;
        if (zone == 0) {
            if (!grid.isEmpty()) host.onLaunch(grid.get(gi));
        } else if (zone == 1) {
            if (di < dock.size()) host.onLaunch(dock.get(di));
        } else if (si != 0) {
            int id = TILE_ID[si];
            closeShade();
            host.onTile(id);
        }
    }

    /** Удержание OK. */
    void longCenter() {
        if (host == null) return;
        if (zone == 0 && !grid.isEmpty()) host.onMenu(grid.get(gi), false);
        else if (zone == 1 && di < dock.size()) host.onMenu(dock.get(di), true);
    }

    /** Кнопка «Назад»: закрывает пункт управления. Возвращает true, если нажатие использовано. */
    boolean back() {
        if (zone == 2) {
            closeShade();
            return true;
        }
        return false;
    }

    // Касания и воздушная мышь
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP || host == null || zone == 2) return true;
        float x = e.getX();
        float y = e.getY();
        for (int i = 0; i < dock.size() && i < dockRects.length; i++) {
            if (dockRects[i].contains(x, y)) {
                host.onLaunch(dock.get(i));
                return true;
            }
        }
        if (y >= gridTop && y <= gridClipBottom) {
            int col = (int) ((x - gridLeft) / colW);
            int row = (int) ((y - gridTop + scrollY) / rowH);
            int idx = row * cols + col;
            if (col >= 0 && col < cols && idx >= 0 && idx < grid.size()) {
                gi = idx;
                host.onLaunch(grid.get(idx));
            }
        }
        return true;
    }
}
